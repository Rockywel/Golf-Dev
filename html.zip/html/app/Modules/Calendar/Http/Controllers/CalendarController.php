<?php

namespace App\Modules\Calendar\Http\Controllers;

use App\Http\Controllers\Controller;

class CalendarController extends Controller
{
    public function index()
    {
        return view('calendar/calendar-list');
    }
}