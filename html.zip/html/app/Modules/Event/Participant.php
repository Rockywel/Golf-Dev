<?php

namespace App\Modules\Event;

use Illuminate\Database\Eloquent\Model;

class Participant extends Model
{
    protected $guarded = [];
}
