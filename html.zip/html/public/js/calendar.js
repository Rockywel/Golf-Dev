var now = new Date();

var day = now.getDate();
const weekdays = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

var monthNumber = now.getMonth();
const monthsOfTheYear = [{"January":31}, {"February":28}, {"March":31}, {"April":30}, {"May":31}, {"June":30}, {"July":31}, {"August":31}, {"September":30}, {"October":31}, {"November":30}, {"December":31}];
var month = String(Object.keys(monthsOfTheYear[monthNumber]));

var year = now.getFullYear();



document.getElementById("month&Year").innerHTML = `<ul><li class="prev">&#10094;</li><li class="next">&#10095;</li><li>${month}<br><span style="font-size:18px">${year}</span></li>`;



const numberOfDaysInTheWeek = 7;
var createdElement = "li";
var childElements = document.getElementById("weekdays").getElementsByTagName(createdElement);
for(dayTick=0; dayTick<numberOfDaysInTheWeek; dayTick++){
        document.getElementById("weekdays").appendChild(document.createElement(createdElement));
        childElements[dayTick].innerHTML = String(weekdays[dayTick]);
}



var daysInTheMonth = eval(`monthsOfTheYear[monthNumber].${Object.keys(monthsOfTheYear[monthNumber])}`);
var createdElement = "li";
var childElements = document.getElementById("days").getElementsByTagName(createdElement);
for(dayTick=1; dayTick<=daysInTheMonth; dayTick++){
        document.getElementById("days").appendChild(document.createElement(createdElement));
        childElements[dayTick-1].innerHTML = String(dayTick);
}
var createdElement = "span";
childElements[day-1].innerHTML = `<span class="active">${day}</span>`





const colorsOfTheMonth = [{"January":"#99c1dc"}, {"February":"#e0dee3"}, {"March":"#6fc0b1"}, {"April":"#dadeb5"}, {"May":"#cd6766"}, {"June":"#bdda57"}, {"July":"#a6c1e1"}, {"August":"#ffd79"}, {"September":"#d0be55"}, {"October":"#e79424"}, {"November":"#abb7bb"}, {"December":"#e0e8db"}];
var currentDayStyle = childElements[day-1].style.background = eval(`colorsOfTheMonth[monthNumber].${Object.keys(colorsOfTheMonth[monthNumber])}`);
var currentMonthStyle = document.getElementById("month&Year").style.background = eval( `colorsOfTheMonth[monthNumber].${Object.keys(colorsOfTheMonth[monthNumber])}`);
