export const apiDomain = window.Laravel.basePath
export const registrationUrl = apiDomain + 'api/v1/handleRegistration'
export const stockData = apiDomain + 'api/v1/stock-data'