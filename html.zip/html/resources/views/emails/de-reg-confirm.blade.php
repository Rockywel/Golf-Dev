Hi {{$user->name}},

<p>We have received your request for de-registering from the event.</p>

<p>
    Thanks,
    <br>
    Jared Holland
</p>
