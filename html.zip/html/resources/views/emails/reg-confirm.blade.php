Hi {{$user->name}},

<p>We have received your request for registering to the event.</p>

<p>This is a system generated email and soon you will get another email with your event pass.</p>

<p>
    Thanks,
    <br>
    Jared Holland
</p>
