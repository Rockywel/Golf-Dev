@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Dashboard
                    <span class="pull-right"><i class="fa fa-dashboard"></i></span>
                </div>

                <div class="panel-body">
                    You are logged in!
		    <span><i class="fas fa-golf-ball"></i></span>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Clock
                    <span class="pull-right"><i class="fa fa-clock-o"></i></span>
                </div>

                <div class="panel-body">
                    <clock></clock>
                </div>
            </div>
        </div>
    </div>
	<h2>No events currently active...</h2>
</div>
@endsection
