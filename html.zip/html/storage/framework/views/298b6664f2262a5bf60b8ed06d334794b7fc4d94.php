<?php $__env->startSection('content'); ?>
<head>
    <link href="<?php echo e(asset('css/calendar.css')); ?>" rel="stylesheet">

</head>
<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Calendar Settings
                    <span class="pull-right"><i class="fa fa-calendar"></i></span>
                </div>

                <div class="panel-body">
                <div class="btn btn-primary" style="position:relative;width:100%">Edit</div>
                    
		    <span><i class="fas fa-golf-ball"></i></span>
                </div>
            </div>
            <div class="calendar">
                <div id="month&Year" class="month">
                </div>
                <ul id="weekdays" class="weekdays">
                </ul>
                <ul id="days" class="days">
                </ul>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('js/calendar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>