<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-8 col-sm-push-2">
            <h1>My profile <span class="pull-right"><i class="fa fa-user-circle"></i></span></h1>
            <hr>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-8 col-sm-push-2">
            <div class="panel panel-default">
                <div class="panel-heading">Edit my profile</div>
                <div class="panel-body">
                    <form action="<?php echo e(route('profile-save')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name', $user->name)); ?>">
                        </div>

                        <div class="form-group">
                            <label for="email">Email address</label>
                            <input type="text" id="email" class="form-control" value="<?php echo e($user->email); ?>" disabled>
                        </div>

                        <event-location
                            lat="<?php echo e($user->lat); ?>"
                            long="<?php echo e($user->long); ?>"
                            zoom-level="15">
                        </event-location>

                        <div class="form-group">
                            <br>
                            <button class="btn btn-primary">
                                Save <i class="fa fa-upload"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>