<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script>
      window.Laravel = { csrfToken: '<?php echo e(csrf_token()); ?>', basePath: '<?php echo e(url("/")); ?>/' }
    </script>
    <title>Golfing Events</title>
    <link rel="stylesheet" href="<?php echo e(url('css/font-awesome.min.css')); ?>">
   <!--  <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>"> -->
    <link href="<?php echo e(asset('css/appy.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('header-styles'); ?>
<head>
<body>
	<img src="https://greenvillejournal.com/wp-content/uploads/2019/08/synex-golf.jpg" height="150px" width="100%" alt="Golfing image">
   <?php echo $__env->make('partials.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container" id="app">

        <div class="content-container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

    </div>

    <script src="//cdn.ckeditor.com/4.7.1/standard/ckeditor.js"></script>
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
</body>
</html>
