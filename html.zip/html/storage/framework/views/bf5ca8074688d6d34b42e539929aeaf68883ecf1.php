<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-7 col-sm-12">
            <h1>Upcoming events
                <span class="pull-right"><a href="<?php echo e(route('event-add')); ?>" class="btn btn-primary">Add Event</a></span>
            </h1>

            <hr>

            <?php $__currentLoopData = $upcomingEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upcomingEvent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <a href="<?php echo e(route('event-view', $upcomingEvent->slug)); ?>">
                                #<?php echo e($upcomingEvent->id); ?> <?php echo e($upcomingEvent->title); ?>

                            </a>
                        </h3>
                    </div>
                    <div class="panel-body">
                        <div class="meta-data margin-bottom-20">
                            <strong>Start date: </strong><?php echo e($upcomingEvent->start_date); ?>,
                            <strong>End date: </strong><?php echo e($upcomingEvent->end_date); ?>

                            <br>
                            <strong>Created by: </strong><a href="#"><?php echo e($upcomingEvent->creator->name); ?></a>
                        </div>
                        <div class="description margin-bottom-20">
                            <?php echo limit_words($upcomingEvent->description, 50); ?>

                        </div>
                        <div class="register-button-container">
                            <a href="<?php echo e(route('event-view', $upcomingEvent->slug)); ?>" class="btn btn-info">
                                <i class="fa fa-eye"></i> View
                            </a>
                            <?php if($upcomingEvent->user === null): ?>
                                <event-registration text="Register"
                                                    mode="btn-primary"
                                                    event-id="<?php echo e($upcomingEvent->id); ?>" class="pull-left margin-right-10"></event-registration>
                            <?php else: ?>
                                <event-registration text="De-register"
                                                    mode="btn-warning"
                                                    event-id="<?php echo e($upcomingEvent->id); ?>"></event-registration>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <h1>Past events</h1>

            <?php $__currentLoopData = $pastEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pastEvent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <a href="<?php echo e(route('event-view', $pastEvent->slug)); ?>">
                                #<?php echo e($pastEvent->id); ?> <?php echo e($pastEvent->title); ?>

                            </a>
                        </h3>
                    </div>
                    <div class="panel-body">
                        <div class="meta-data margin-bottom-20">
                            <strong>Start date: </strong><?php echo e($pastEvent->start_date); ?>,
                            <strong>End date: </strong><?php echo e($pastEvent->end_date); ?>

                            <br>
                            <strong>Created by: </strong><a href="#"><?php echo e($pastEvent->creator->name); ?></a>
                        </div>
                        <div class="description margin-bottom-20">
                            <?php echo limit_words($pastEvent->description, 50); ?>

                        </div>
                        <div class="register-button-container">
                            <a href="<?php echo e(route('event-view', $pastEvent->slug)); ?>" class="btn btn-warning">
                                <i class="fa fa-eye"></i> View
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="col-md-4 col-md-push-1 col-sm-12">
            <h3>Tournaments near me</h3>

            <?php if($eventsNearBy != null): ?>
                <div class="list-group">
                    <?php $__currentLoopData = $eventsNearBy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('event-view', $event->slug)); ?>" class="list-group-item">
                            <h4 class="list-group-item-heading"><?php echo e($event->title); ?></h4>
                            <p class="list-group-item-text">
                                <strong>Address:</strong> <?php echo e($event->address); ?>

                                <br>
                                <strong>Start date:</strong> <?php echo e($event->start_date); ?>

                                <br>
                                <strong>End date:</strong> <?php echo e($event->end_date); ?>

                                <br>
                                <strong>Distance from home:</strong> <?php echo e(round($event->distance, 2)); ?>

                            </p>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php else: ?>
                <p>No tournaments nearby</p>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('html', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>