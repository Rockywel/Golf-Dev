<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('event-save')); ?>" method="post" id="locationForm">
        <div class="row">
            <div class="col-sm-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Add new event</h3>
                    </div>
                    <div class="panel-body">

                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="title">Event title</label>
                            <input type="text" name="title" id="title" class="form-control" placeholder="Enter the event">
                            <span class="error"><?php echo e($errors->first('title')); ?></span>
                        </div>

                        <div class="form-group">
                            <label for="title">Address</label>
                            <input type="text" name="address" id="address" class="form-control"
                                   placeholder="Enter the event address">
                            <span class="error"><?php echo e($errors->first('address')); ?></span>
                        </div>

                        <div class="form-group">
                            <label for="title">Start date</label>
                            <input type="date" name="start_date" id="start_date" class="form-control"
                                   placeholder="Enter the event start date">
                            <span class="error"><?php echo e($errors->first('start_date')); ?></span>
                        </div>

                        <div class="form-group">
                            <label for="title">End date</label>
                            <input type="date" name="end_date" id="end_date" class="form-control"
                                   placeholder="Enter the event end date">
                            <span class="error"><?php echo e($errors->first('end_date')); ?></span>
                        </div>

                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea name="description" class="form-control"
                                      placeholder="Enter the description" id="description"></textarea>
                            <span class="error"><?php echo e($errors->first('description')); ?></span>
                        </div>

                        <button class="btn btn-primary">
                            <i class="fa fa-save"></i> Save
                        </button>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Select the location</h3>
                    </div>
                    <div class="panel-body">
                        <div class="form-group">
                            <span class="error"><?php echo e($errors->first('lat')); ?></span>
                            <span class="error"><?php echo e($errors->first('long')); ?></span>
                            <event-location></event-location>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-script'); ?>
    <script>
        CKEDITOR.replace('description')
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('html', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>