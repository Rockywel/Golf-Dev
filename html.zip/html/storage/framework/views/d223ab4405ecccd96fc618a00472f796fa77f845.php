<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-8 col-sm-push-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-heading"><?php echo e($event->title); ?></h3>
                </div>
                <div class="panel-body content">
                    <p><strong>Description:</strong></p>
                    <?php echo $event->description; ?>

                </div>

                <div id="map"></div>
                <gmap-map
                    :center="<?php echo e(json_encode([ 'lat' => $event->lat, 'lng' => $event->lng ])); ?>"
                    :zoom="6"
                    style="width: 100%; height: 300px">
                </gmap-map>

                <table class="table table-bordered table-hover table-striped">
                    <tbody>
                    <tr>
                        <td><strong>Start date:</strong></td>
                        <td><?php echo e($event->start_date); ?></td>
                    </tr>
                    <tr>
                        <td><strong>End date:</strong></td>
                        <td><?php echo e($event->end_date); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Address:</strong></td>
                        <td><?php echo e($event->address); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Created by:</strong></td>
                        <td><a href="#"><?php echo e($event->creator->name); ?></a></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>